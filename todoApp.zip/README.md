# Summary
School assignment where the objectives is to create an todo app with NodeJS, express & handlebars.<br>

## Objectives
The objectives here where to create a todo app wiht Express & Handlebars.<br>
All Todo task should have the following attributes:<br>
<ul>
  <li>Id</li>
  <li>Created (date & Time)</li>
  <li>Description</li>
  <li>Done (true/false)</li>
</ul>
The user should be able to execute all CRUD-operations on todo tasks.<br>
The user can choose to show all tasks, only done or only undone.<br>
The user can sort tasks by when created. Newest → Oldest & Oldest → Newest.
