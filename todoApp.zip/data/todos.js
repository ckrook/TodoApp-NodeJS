const todos = [
  {
    id: 1,
    created: new Date(),
    description: "Click me to edit or delete",
    done: false,
  },
  {
    id: 2,
    created: new Date(),
    description: "Sort list by newest / oldest created",
    done: false,
  },
  {
    id: 3,
    created: new Date(),
    description: "Press green button to add todo",
    done: false,
  },
];

module.exports = todos;
